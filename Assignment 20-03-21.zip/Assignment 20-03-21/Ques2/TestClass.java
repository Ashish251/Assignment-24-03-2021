
public class TestClass{
	
	static Bird bird = new Bird();
	
	public static void main(String[] args){
		// default values of static variables
		System.out.println("Bird : Static Variables ");
		System.out.println("Id :" + bird.id);
		System.out.println("Average Height : "+bird.avgHeight+" feet");
		System.out.println("Average Speed : "+bird.avgSpeed+" mph");
		System.out.println("Has wings : "+bird.hasWings);
		System.out.println("Name : "+bird.name);
		
		//default values of instance variables
		System.out.println("\nBird : Instance Variables ");
		System.out.println("Id :" + bird.id1);
		System.out.println("Average Height : "+bird.averageHeight1+" feet");
		System.out.println("Average Speed : "+bird.averageSpeed1+" mph");
		System.out.println("Has wings : "+bird.hasWings1);
		System.out.println("Name : "+bird.name1);
		
		//Object Reference of Bird
		
		System.out.println("\nTestClass : Object reference");
		System.out.println("Bird : "+bird);
	}
}