import java.util.*;

public class Sum{
	
	public int add(int[] numbers){
		
		int sum = 0;
		for(int n : numbers){
			sum += n;
		}
		
		return sum;
	}
	
	public String Sumconcat(int[] numbers){
		
		String str = "";
		
		for(int n: numbers){
			str += String.valueOf(n)+" ";
		}
		
		return str;
	}
	
	
	public static void main(String[] args){
		
		Sum sum = new Sum();
		int[] arr = {1,2,3,4,5}; 
		
		System.out.println("Sum : "+sum.add(arr));
		System.out.println("After Concatenation : "+sum.Sumconcat(arr));
		
	}
	
}