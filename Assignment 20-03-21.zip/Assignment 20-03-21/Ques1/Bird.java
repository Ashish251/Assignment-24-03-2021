public class Bird{
	static int id;
	static float avgHeight;
	static double avgSpeed;
	static boolean hasWings;
	static String name;
	
	int id1;
	float avgHeight1;
	double avgSpeed1;
	boolean hasWings1;
	String name1;
	
	public void fly(){
		System.out.println("Bird : fly()");
	}
	
	
}